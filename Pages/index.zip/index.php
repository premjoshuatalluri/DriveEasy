<?php
include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Driver's Dashboard</title>
  <style>
    body {
      font-family: sans-serif;
      margin: 0;
    }

    /* Header */
    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px;
      background-color: #333;
      margin-left: 200px;
      border-bottom: 2px solid #333; /* Added border-bottom to create border only at the bottom */
    }

    .logo {
      font-size: 20px;
      font-weight: bold;
      color: #fff;
    }

    .profile {
      display: flex;
      align-items: center;
    }

    .profile img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
    }

    /* Header */
header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  background-color: #333;
  margin-left: 200px; /* Adjusted margin-left to 0 */
  border-bottom: 2px solid #333; /* Added border-bottom to create border only at the bottom */
}

/* User Info */
.user-info {
  margin-left: 10px;
  text-align: right; /* Align user info to the right */
  color: white; /* Adjust text color */
  padding-right: 20px; /* Adjusted padding to provide more space */
}

    .user-info h1 {
      font-size: 16px;
      margin-bottom: 5px;
      text-align: center;
    }

    .user-info p {
      font-size: 14px;
      margin-bottom: 0;
    }


    /* Main */
    main {
      display: flex;
    }

    /* Navigation */
    nav {
      background-color: #333;
      color: white;
      padding: 10px;
      position: fixed;
      height: 100%;
      width: 200px;
      top: 0;
      left: 0;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      border-right: 2px solid #333; /* Added border-right to create border only on the right */
    }

    nav h2 {
      color: white;
      font-size: 18px;
      margin-bottom: 10px;
      border-bottom: 2px solid white;
    }

    nav a {
      text-decoration: none;
      color: white;
      padding: 8px;
      display: block;
      margin-bottom: 2px;
      width: 100%;
      text-align: center;
      line-height: 30px;
    }

    /* Dashboard Content */
    .dashboard-content {
      flex: 1;
      padding: 20px;
      margin-left: 200px;
    }

    .dashboard-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    .employee-dropdown {
      margin-left: 20px; /* Adjust margin */
    }

    /* Dashboard Card */
    .dashboard-card {
      width: 25%;
      padding: 20px;
      background-color: #fff;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-bottom: 20px;
    }

    .dashboard-card h3 {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .dashboard-card p {
      font-size: 14px;
      margin-bottom: 5px;
    }

 /* Logout Button */
.logout {
  background-color: #333;
  color: white;
  text-align: center;
  padding: 10px;
  position: fixed;
  bottom: 0;
  width: 100%; /* Adjusted width to 100% */
  border-top: 2px solid #333; /* Added border-top to create border only at the top */
}

.logout form {
  margin-bottom: 5px;
}
  </style>
</head>
<body>

<?php
session_start();

// Placeholder values, replace them with your actual data or logic
$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Lekhika";
$id = isset($_SESSION['id']) ? $_SESSION['id'] : "2557661";

// Placeholder values for counts
$totalBookings = 100;
$totalCars = 50;
$totalRevenue = "$50,000";
$cancelledBookings = 10;
?>

  <header>
    <div class="logo">DriveEasy</div>
    <div class="dashboard-header">
      <div class="user-info">
        <h1>Hi, <?php echo $username; ?>!</h1>
        <p>ID: <?php echo $id; ?></p>
      </div>
    </div>
  </header>

  <main>
    <nav>
      <h2>Dashboard</h2>
      <a href="#">Employee Management</a>
      <a href="#">Bookings</a>
      <a href="#">Inventory</a>
      <a href="#">Customers</a>
      <a href="#">Reports</a>
      <a href="#">Settings</a>
      <a href="#">Help/Support</a>

      <div class="logout">
    <form action="logout.php" method="post">
        <input type="submit" value="Logout">
    </form>
</div>
    </nav>

    <div class="dashboard-content">
      <div class="dashboard-header">
        <!-- Move the dropdown to this section -->
        <div class="employee-dropdown">
          <select name="branch" id="branch">
            <option value="all">All Branches</option>
            <?php
            // Output branch options
            if (isset($Branches)) {
                foreach ($Branches as $branch) {
                    echo "<option value='" . $branch['Branch_ID'] . "'>" . $branch['Branch_Name'] . "</option>";
                }
            }
            ?>
          </select>
        </div>
      </div>

      <div class="dashboard-card">
        <h3>Bookings</h3>
        <p>Total Bookings: <span id="total_bookings"><?php echo $totalBookings; ?></span></p>
        <p>Total Cars: <span id="total_cars"><?php echo $totalCars; ?></span></p>
        <p>Total Revenue: <span id="total_revenue"><?php echo $totalRevenue; ?></span></p>
        <p>Cancelled: <span id="cancelled"><?php echo $cancelledBookings; ?></span></p>
      </div>

      <div class="dashboard-card">
        <h3>Inventory</h3>
        <p>Week: <span id="inventory_week"><?php echo getInventoryWeekCount(); ?></span></p>
        <p>Today: <span id="inventory_today"><?php echo getInventoryTodayCount(); ?></span></p>
      </div>

      <div class="dashboard-card">
        <h3>Customers</h3>
        <p>Booked Cars: <span id="booked_cars"><?php echo getCustomerBookedCarsCount(); ?></span></p>
        <p>Quick Links: <span id="quick_links">Generate Customer Reports, Complaints</span></p>
      </div>

      <div class="dashboard-card">
        <h3>Reports</h3>
        <p>BMW: <span id="bmw_report"><?php echo getBMWRating(); ?></span></p>
        <p>Audi: <span id="audi_report"><?php echo getAudiRating(); ?></span></p>
        <p>Mercedes: <span id="mercedes_report"><?php echo getMercedesRating(); ?></span></p>
        <p>Cooper: <span id="cooper_report"><?php echo getCooperRating(); ?></span></p>
      </div>

      <div class="dashboard-card">
        <h3>Settings</h3>
        <p>Volkswagen: <span id="volkswagen_report"><?php echo getVolkswagenRating(); ?></span></p>
        <p>Range Rover: <span id="range_rover_report"><?php echo getRangeRoverRating(); ?></span></p>
      </div>
    </div>
  </main>
          </body>
          </html>
